﻿using System.Reflection;
using System.Transactions;


//stated the class name including namespace
Console.WriteLine("Enter class name");
string className = "Furniture." + Console.ReadLine();

Type? classType = Type.GetType(className);
Console.WriteLine(classType);
if (classType == null)
{
    throw new NullReferenceException();
}

var type = CreateInstance(classType);


Console.WriteLine("Enter method name");
string? methodName = Console.ReadLine();
if (methodName == null)
{
    throw new NullReferenceException();
}

MethodInfo? classMethod = classType.GetMethod(methodName);

if (classMethod == null)
{
    Console.WriteLine("No such method");
}
else
{
    foreach (var param in classMethod.GetParameters())
    {
        Console.WriteLine(param);
    }
}






object? CreateInstance(Type classType)
{
    ConstructorInfo? ctorChoice = ChooseCtor(classType);
    if (ctorChoice == null)
    {
        throw new NullReferenceException();
    }
    ParameterInfo[] ctorParams = ctorChoice.GetParameters();
    object?[]? parameters = ReturnParams(ctorParams);

    return ctorChoice.Invoke(parameters);
}

ConstructorInfo? ChooseCtor(Type classType)
{
    List<ConstructorInfo> ctors = new List<ConstructorInfo>();

    Console.WriteLine("Now Let's create an instance\n Here are all constructors");
    for(int i = 0; i < classType.GetConstructors().Length; i++)
    {
        ConstructorInfo[] ctorArr = classType.GetConstructors();
        Console.WriteLine($"{i+1}. {ctorArr[i]}");
        ctors.Add(ctorArr[i]);
    }

    Console.WriteLine("Enter the number of the one you want");
    string? choice = Console.ReadLine();
    if (String.IsNullOrEmpty(choice))
    {
        throw new NullReferenceException();
    }

    int choiceInt = int.Parse(choice);

    var ctorChoice = ctors[choiceInt - 1];

    return ctorChoice;
}



object?[]? ReturnParams(ParameterInfo[] ctorParams)
{
    List<string> choicesStr = new List<string>();
    List<object> objList = new List<object>();

    for (int i = 0; i < ctorParams.Length; i++)
    {
        Console.WriteLine("Enter " + ctorParams[i].Name);
        string? choice = Console.ReadLine();
        if (String.IsNullOrEmpty(choice))
        {
            return null;
        }
        //converts string to simple ParameterType and adds to return array
        objList.Add(Convert.ChangeType(choice, ctorParams[i].ParameterType));
    }

    return objList.ToArray();
}